package com.readme.service;

import com.readme.dto.MemberDetailVO;
import com.readme.dto.MemberVO;

public interface MemberDetailService{

	public int updateMemberDetail(MemberDetailVO memberDetailVO);
	
	
}
