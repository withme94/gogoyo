package com.readme.dto;

public class MemberLikeVO {

	private String yourId;
	private String wish_id;
	
	
	public String getYourId() {
		return yourId;
	}
	public void setYourId(String yourId) {
		this.yourId = yourId;
	}
	public String getWish_id() {
		return wish_id;
	}
	public void setWish_id(String wish_id) {
		this.wish_id = wish_id;
	}
	
	
}
