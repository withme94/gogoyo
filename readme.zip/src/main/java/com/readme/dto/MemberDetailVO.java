package com.readme.dto;

public class MemberDetailVO {

	private String id;
	private String comment;
	private String url;
	private String portfolio_name;
	private String portfolio_path;
	private String portfolio_thumbnail_path;
	private String skill;
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPortfolio_name() {
		return portfolio_name;
	}
	public void setPortfolio_name(String portfolio_name) {
		this.portfolio_name = portfolio_name;
	}
	public String getPortfolio_path() {
		return portfolio_path;
	}
	public void setPortfolio_path(String portfolio_path) {
		this.portfolio_path = portfolio_path;
	}
	public String getPortfolio_thumbnail_path() {
		return portfolio_thumbnail_path;
	}
	public void setPortfolio_thumbnail_path(String portfolio_thumbnail_path) {
		this.portfolio_thumbnail_path = portfolio_thumbnail_path;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	
	
	
}
