package com.readme.dto;

public class MemberVO {
	 
	private String id;
    private String password;
    private String name;
    private int jumin;
    private String phone;
	private String region;
	private String profileImg;
	private String profileThumbImg;
    
    
    
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getJumin() {
		return jumin;
	}
	public void setJumin(int jumin) {
		this.jumin = jumin;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getProfileImg() {
		return profileImg;
	}
	public void setProfileImg(String profileImg) {
		this.profileImg = profileImg;
	}
	public String getProfileThumbImg() {
		return profileThumbImg;
	}
	public void setProfileThumbImg(String profileThumbImg) {
		this.profileThumbImg = profileThumbImg;
	}
    
    
    
    
    
    
    
    
    
//    private String profileimg;
//    private String signDate;
//    
    
//	public String getProfileimg() {
//		return profileimg;
//	}
//	public void setProfileimg(String profileimg) {
//		this.profileimg = profileimg;
//	}
//	public String getSignDate() {
//		return signDate;
//	}
//	public void setSignDate(String signDate) {
//		this.signDate = signDate;
//	}
    

	
 
 
}

