package com.readme.dto;

public class MemberProfileVO {

	private String id;
    private String name;
    private int jumin;
    private String phone;
	private String region;
	private String profileImg;
	private String profileThumbImg;
	private String comment;
	private String url;
	private String portfolio_name;
	private String portfolio_path;
	
	
	
	
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getJumin() {
		return jumin;
	}
	public void setJumin(int jumin) {
		this.jumin = jumin;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getProfileImg() {
		return profileImg;
	}
	public void setProfileImg(String profileImg) {
		this.profileImg = profileImg;
	}
	public String getProfileThumbImg() {
		return profileThumbImg;
	}
	public void setProfileThumbImg(String profileThumbImg) {
		this.profileThumbImg = profileThumbImg;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPortfolio_name() {
		return portfolio_name;
	}
	public void setPortfolio_name(String portfolio_name) {
		this.portfolio_name = portfolio_name;
	}
	public String getPortfolio_path() {
		return portfolio_path;
	}
	public void setPortfolio_path(String portfolio_path) {
		this.portfolio_path = portfolio_path;
	}
	
	
	
}
