package com.readme.dao;

import com.readme.dto.MemberDetailVO;
import com.readme.dto.MemberVO;

public interface MemberDetailDAO {

	
	public int updateMemberDetail(MemberDetailVO memberDetailVO);
	
	
}
