window.onload = function(){
    console.log("들어옴");
}